# FLC
A Lethal Company mod. Adds a bunch of new monsters, scrap and ship upgrades.
